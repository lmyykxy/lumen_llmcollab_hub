# 陆小七完整人格提示文件夹 v0.3.1

本包是完整版本，不是补丁。已合并：

- v0.2 艺术化人格文件
- v0.3 视觉设定
- v0.3.1「眼睛固定 / 眼镜可变」修正
- 旧项目 `SOUL.md` / `IDENTITY.md` 作为迁移参考

## 目录结构

```text
01_prompts_final/          # 最终可用人格/提示文件
02_visual_patch_notes/     # 视觉补丁记录
03_legacy_reference/       # 旧项目原始文件，仅供参考，不建议直接加载
04_backend_usage/          # 后端加载建议
```

## 最重要视觉规则

```text
眼睛 = 固定身份特征
眼镜 = 可变配饰
```

固定身份锚点：

```text
头发、帽子、眼睛、面貌气质、体型
```

可变元素：

```text
眼镜、穿着、姿势、场景、光照、表情强度
```

## 不要直接加载 legacy_reference

`03_legacy_reference` 里是旧 OpenClaw / 群聊机器人版本，包含很多不适合当前 App 的内容，例如每条必须喵、SENDIMG、NO_REPLY、群成员关系等。它们只用来追溯，不要直接作为系统 Prompt。

## 推荐加载方式

### 聊天

```text
01_CHARACTER_BIBLE.md
02_SOUL_EXPANDED.md
03_VOICE_AND_LANGUAGE.md
04_EMOTIONAL_ARCHITECTURE.md
05_RELATIONSHIP_ARCS.md
06_LIFEFLOW_ENGINE.md 当前状态摘要
07_MEMORY_SYSTEM.md 检索记忆摘要
12_SAFETY_AND_OUTPUT.md
13_SYSTEM_PROMPT_TEMPLATE.md
```

### 图片生成

```text
09_VISUAL_BIBLE.md
11_IMAGE_PROMPT_GUIDE.md
当前 CharacterState / OutfitState / RoomState / WeatherState
```

### 日记 / 朋友圈

```text
01_CHARACTER_BIBLE.md
02_SOUL_EXPANDED.md
06_LIFEFLOW_ENGINE.md
07_MEMORY_SYSTEM.md
08_DIARY_MOMENTS_PHOTO.md
12_SAFETY_AND_OUTPUT.md
```
