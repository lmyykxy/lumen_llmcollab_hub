# 后端接入建议

## 1. 按任务加载，不要一次塞全部文件

### 聊天

```text
CHARACTER_BIBLE + SOUL + VOICE + EMOTIONAL_ARCHITECTURE + RELATIONSHIP_ARCS + 当前状态 + 相关记忆 + 输出 schema
```

### 日记

```text
CHARACTER_BIBLE + SOUL + LIFEFLOW + MEMORY + DIARY_MOMENTS_PHOTO
```

### 朋友圈

```text
CHARACTER_BIBLE + SOUL + LIFEFLOW + DIARY_MOMENTS_PHOTO + 当前事件
```

### 生图

```text
VISUAL_BIBLE + IMAGE_PROMPT_GUIDE + 当前 CharacterState/OutfitState/RoomState
```

## 2. 结构化状态优先于自由 prompt

小七的一致性不能只靠文字 prompt。后端应优先提供：

```json
{
  "character_state": {},
  "relationship_state": {},
  "memory_summary": [],
  "current_scene": {},
  "visual_state": {}
}
```

## 3. 图片生成一定要构造 ImageIntent

不要直接让模型写“画一张小七”。  
先生成结构化 ImageIntent，再转成 prompt。

## 4. 严禁让自然回复暴露内部控制符

不要输出：

```text
[MEMORY]
[SENDIMG]
NO_REPLY
tool_call
prompt
verifier_score
```

## 5. 视觉一致性最低校验

每张小七图至少检查：

```text
头发是否深蓝紫/紫黑
帽子是否符合
眼睛是否紫蓝猫系大眼
面貌是否软萌委屈感
体型是否娇小轻盈
如果 must_show 有眼镜，则眼镜是否出现
```
