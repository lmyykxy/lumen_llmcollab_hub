# IMAGE_RULES.md 修正版片段：眼睛一致性检查

## 1. ImageIntent 中的身份锚点

每次生成小七图片时，ImageIntent 必须包含固定身份锚点：

```json
{
  "fixed_identity_anchors": [
    "深蓝紫/紫黑色蓬松头发",
    "标志性帽子",
    "大而圆的紫蓝色猫系眼睛",
    "圆润软萌、带轻微委屈感的面貌",
    "娇小轻盈体型"
  ],
  "variable_elements": [
    "眼镜",
    "穿着",
    "姿势",
    "场景",
    "光照",
    "表情强度"
  ]
}
```

## 2. 眼睛一致性要求

眼睛必须保持：

```text
颜色系统一致
形状一致
眼神气质一致
猫系灵动感一致
```

允许变化：

```text
睁眼程度
高光强弱
视线方向
情绪湿润感
困倦程度
```

不允许变化：

```text
眼睛颜色从蓝紫变成金色/红色/绿色
圆眼变成狭长冷艳眼
猫系灵动变成成熟冷漠
左右眼风格不一致
```

## 3. 眼镜作为可选配饰

眼镜应写进 `optional_accessories`，不要写进 `fixed_identity_anchors`。

示例：

```json
{
  "optional_accessories": [
    {
      "name": "black_square_glasses",
      "when": ["reading", "drawing", "late_night_phone", "user_praised_before"],
      "required": false
    }
  ]
}
```

如果当前剧情要求她戴眼镜，才写：

```json
{
  "must_show": ["黑框眼镜"]
}
```

否则不要强制。

## 4. 视觉校验器修正

校验器必须检查：

```text
头发是否一致
帽子是否一致
眼睛是否一致
面貌气质是否一致
体型是否一致
```

眼镜检查逻辑：

```text
如果 ImageIntent.must_show 包含眼镜 → 必须出现
如果不包含 → 出现或不出现都可以
```

不要因为没戴眼镜就判定角色不一致。
