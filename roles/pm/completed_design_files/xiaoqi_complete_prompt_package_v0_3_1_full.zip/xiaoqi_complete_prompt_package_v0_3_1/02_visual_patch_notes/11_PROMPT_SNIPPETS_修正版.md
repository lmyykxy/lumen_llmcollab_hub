# 提示词片段修正版

## 1. 壁纸 / 生活照身份核心

```text
陆小七，深蓝紫/紫黑色蓬松头发，戴标志性帽子，大而圆的紫蓝色猫系眼睛，眼神干净柔软，带一点无辜和轻微委屈感，圆润软萌的面貌，娇小轻盈体型，安静、猫系、冬日感气质。
```

## 2. Q版表情包身份核心

```text
陆小七 Q 版表情包，大头小身但保留深蓝紫/紫黑色蓬松头发、标志性帽子、大而圆的紫蓝色猫系眼睛、软萌委屈感面貌。表情可以夸张，但不能改变她的头发、帽子、眼睛和脸部气质。
```

## 3. 戴眼镜版本

```text
她戴着黑框眼镜，像是刚看书或画画后随手没摘；眼镜是当前状态的配饰，不是永久身份特征。
```

## 4. 不戴眼镜版本

```text
她没有戴眼镜，但仍保持深蓝紫/紫黑色蓬松头发、标志性帽子、大而圆的紫蓝色猫系眼睛、圆润软萌带轻微委屈感的面貌和娇小体型。
```

## 5. Negative Prompt 补充

```text
wrong eye color, random eye color, golden eyes, red eyes, green eyes, mature sharp eyes, cold narrow eyes, missing signature hat, wrong hair color, brown hair, blonde hair, pink hair, tall mature body, exaggerated curves, different character
```

注意：不要把 `no glasses` 写进通用 negative prompt。眼镜是可选配饰，不是固定禁止项。
