# IMAGE_PROMPT_GUIDE.md - 生图提示与一致性规则

## 不要直接让模型自由画

错误：

```text
画一张小七在卧室的图。
```

正确：先生成 ImageIntent，再转提示词。

---

## ImageIntent 必备字段

```json
{
  "source_event_id": "evt_001",
  "image_type": "chat_selfie",
  "narrative_context": "用户问她是不是不开心，她嘴硬说没事",
  "character_id": "xiaoqi",
  "visual_version": "v0.2",
  "location_id": "bedroom_window_v1",
  "outfit_id": "lazy_room_v1",
  "outside_view_id": "apartment_rainy_v1",
  "must_show": [],
  "must_not_show": [],
  "emotional_signal": "装作没事但眼神有点困",
  "relationship_signal": "手机放在手边，像刚看过消息",
  "caption_style": "短句、嘴硬、不要解释"
}
```

---

## 正向提示词结构

```text
[角色固定描述]
[服装]
[姿势 / 镜头]
[房间 / 背景]
[窗外]
[情绪]
[物件线索]
[风格限制]
```

示例：

```text
anime style, cozy winter atmosphere, Xiaoqi, petite cat-eared girl, deep purple hair, soft round amber eyes, slightly shy stubborn expression, wearing oversized soft hoodie and thick scarf, sitting near her bedroom window, warm desk lamp, rainy quiet apartment street outside the window, sketchbook and pudding cup on the desk, phone screen faintly lit, slightly messy but cozy room, casual selfie angle, gentle melancholy, no text, no watermark, no petals, no white noise dots
```

---

## 负面提示词

```text
different character, different face, different hair color, no cat ears, mature sexy body, tall model body, exaggerated curves, cyberpunk, luxury room, outdoor beach, forest outside window, random city skyline, English text, watermark, logo, white noise dots, petals, sparkles, over-polished studio portrait, bad hands, extra fingers
```

---

## 场景一致性

推荐使用固定背景或参考图：

- bedroom_window_v1
- bedroom_desk_v1
- bedroom_bed_v1
- outside_apartment_rainy_v1
- outside_apartment_night_v1

不要每张图重新发明房间。

---

## 图片校验问题

生成后用 VLM 或人工检查：

```text
这是小七吗？
猫耳是否存在？
发色是否一致？
身体比例是否娇小？
房间是否一致？
窗外是否是居民区？
天气是否符合？
是否有禁止的白点/花瓣/英文？
图中是否有必须出现的物件？
```

---

## 失败重试策略

| 错误 | 处理 |
|---|---|
| 角色不像 | 重生 |
| 服装错 | 局部重绘 |
| 房间错 | 固定背景重做 |
| 窗外错 | 替换窗外背景 |
| 物件缺失 | 局部添加 |
| 白点/花瓣 | 重生或修图 |
| caption 重复系统话 | 后端清理 |

---

## 图片不要过度艺术化

艺术化不是华丽，而是叙事准确。

优先：

```text
状态真实 > 构图华丽
角色一致 > 画面复杂
房间连续 > 背景炫酷
情绪线索 > 漂亮摆拍
```

---

# v0.3.1 视觉修正规则：眼睛固定，眼镜可变

## 固定身份提示词片段

每次生成小七正常人物图时，必须包含：

```text
陆小七，深蓝紫/紫黑色蓬松头发，戴标志性帽子，大而圆的紫蓝色猫系眼睛，眼神干净柔软，带一点无辜和轻微委屈感，圆润软萌的面貌，娇小轻盈体型，安静、猫系、冬日感气质。
```

## 眼睛一致性

眼睛是固定身份特征，必须保持：

```text
大而圆
紫蓝/蓝紫冷色系
猫系灵动感
干净柔软
轻微委屈感
```

允许改变：睁眼程度、视线方向、高光强弱、困倦程度。  
不允许改变：眼睛颜色系统、眼型身份、猫系气质。

## 眼镜规则

眼镜是可变配饰，不是固定身份特征。

需要戴眼镜时写：

```text
optional black square glasses, worn casually after reading or drawing
```

如果剧情要求必须戴，则写进 `must_show`：

```json
{ "must_show": ["黑框眼镜"] }
```

如果剧情不要求，不要强制。没戴眼镜也可以是小七。

## Q 版提示词

```text
陆小七 Q 版表情包，大头小身但保留深蓝紫/紫黑色蓬松头发、标志性帽子、大而圆的紫蓝色猫系眼睛、软萌委屈感面貌。表情可以夸张，但不能改变她的头发、帽子、眼睛和脸部气质。
```
